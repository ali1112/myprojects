package com.calendarassistant.model;

public class ConfRoom {
    Integer id;
    String name;
    Integer capacity;
    String capabilities;
}
